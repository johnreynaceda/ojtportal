<x-button label="View" class="ml-3" href="{{ route('coordinator.requirements_view', $getRecord()->student->id) }}"
    squared warning outline icon="eye" sm />
