@section('title', 'My Journal')
<x-student-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student.my-journal />
    </div>
</x-student-layout>
