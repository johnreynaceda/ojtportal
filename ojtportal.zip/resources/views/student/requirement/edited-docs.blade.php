@section('title', 'My Requirements')
<x-student-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student.upload-requirement />
    </div>
</x-student-layout>
