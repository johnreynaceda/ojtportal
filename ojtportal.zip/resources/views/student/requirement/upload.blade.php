<x-student-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student.upload-file />
    </div>
</x-student-layout>
