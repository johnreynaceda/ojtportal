@section('title', 'My Tasks')
<x-student-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student.my-task />
    </div>
</x-student-layout>
