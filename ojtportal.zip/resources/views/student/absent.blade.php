@section('title', 'My Absents')
<x-student-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student.my-absent />
    </div>
</x-student-layout>
