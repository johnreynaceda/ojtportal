<x-student-layout>
    <div>
        <livewire:student-dashboard />
    </div>
</x-student-layout>
