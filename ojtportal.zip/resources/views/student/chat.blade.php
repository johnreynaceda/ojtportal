@section('title', 'Chats')
<x-student-layout>
    <livewire:student-chat />
</x-student-layout>
