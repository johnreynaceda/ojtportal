@section('title', 'Daily Time Record')
<x-student-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student.my-dtr />
    </div>
</x-student-layout>
