@section('title', 'TRAINEES')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:trainee-list />
    </div>
</x-supervisor-layout>
