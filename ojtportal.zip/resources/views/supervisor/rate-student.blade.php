@section('title', 'OJT-PERFORMANC RATING')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:supervisor.performance-rating />
    </div>
</x-supervisor-layout>
