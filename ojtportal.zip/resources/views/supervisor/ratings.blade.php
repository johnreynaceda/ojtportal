@section('title', 'RATINGS')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:supervisor.student-rate />
    </div>
</x-supervisor-layout>
