@section('title', 'TASK RECORD')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:supervisor.task-list />
    </div>
</x-supervisor-layout>
