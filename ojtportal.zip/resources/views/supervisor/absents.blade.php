@section('title', 'ABSENTS')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:supervisor.manage-absent />
    </div>
</x-supervisor-layout>
