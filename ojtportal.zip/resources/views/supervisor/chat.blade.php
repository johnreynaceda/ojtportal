@section('title', 'CHATS')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:student-chat />
    </div>
</x-supervisor-layout>
