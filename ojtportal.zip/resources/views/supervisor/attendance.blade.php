@section('title', 'ATTENDANCES')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:supervisor.attendance-list />
    </div>
</x-supervisor-layout>
