<x-supervisor-layout>
    <div>
        <livewire:supervisor-dashboard />
    </div>
</x-supervisor-layout>
