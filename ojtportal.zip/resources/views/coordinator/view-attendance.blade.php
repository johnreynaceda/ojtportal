@section('title', 'DTR RECORDS')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:supervisor.view-dtr />
    </div>
</x-supervisor-layout>
