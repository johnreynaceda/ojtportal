<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.view-requirement />
    </div>
</x-coordinator-layout>
