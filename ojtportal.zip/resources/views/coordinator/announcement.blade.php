@section('title', 'ANNOUNCEMENTS')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.announcement-list />
    </div>
</x-coordinator-layout>
