@section('title', 'USERS')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.user-list />
    </div>
</x-coordinator-layout>
