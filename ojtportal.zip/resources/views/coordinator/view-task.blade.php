@section('title', 'VIEW TASKS')
<x-supervisor-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.view-task />
    </div>
</x-supervisor-layout>
