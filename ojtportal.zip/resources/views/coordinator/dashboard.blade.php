<x-coordinator-layout>
    <div>
        <livewire:coordinator-dashboard />
    </div>
</x-coordinator-layout>
