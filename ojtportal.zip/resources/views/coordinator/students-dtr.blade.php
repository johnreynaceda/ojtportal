@section('title', 'STUDENTS DAILY TIME RECORD')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.student-dtr />
    </div>
</x-coordinator-layout>
