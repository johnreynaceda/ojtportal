@section('title', 'JOURNAL RECORD')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.view-journal />
    </div>
</x-coordinator-layout>
