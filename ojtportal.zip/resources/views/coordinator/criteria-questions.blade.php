@section('title', 'CRITERIA QUETIONS')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.criteria-question-list />
    </div>
</x-coordinator-layout>
