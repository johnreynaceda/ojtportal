@section('title', 'CLASS LISTS')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.class-list />
    </div>
</x-coordinator-layout>
