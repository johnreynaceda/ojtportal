@section('title', 'JOURNAL REPORT')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.journal-list />
    </div>
</x-coordinator-layout>
