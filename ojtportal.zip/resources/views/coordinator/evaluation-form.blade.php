@section('title', 'EVALUATION FORM')
<x-coordinator-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:coordinator.criteria-list />
    </div>
</x-coordinator-layout>
