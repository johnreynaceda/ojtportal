<div>
    <div class="mb-3">
        <h1 class="text-xl font-bold uppercase"> {{ $criteria }}</h1>
        <h1 class="text-gray-500 text-sm">List of all questions in this criteria.</h1>
    </div>
    <div>
        {{ $this->table }}
    </div>
</div>
