<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <script >window.Wireui = {cache: {},hook(hook, callback) {window.addEventListener(`wireui:${hook}`, () => callback())},dispatchHook(hook) {window.dispatchEvent(new Event(`wireui:${hook}`))}}</script>
<script src="http://ojtportal.test/wireui/assets/scripts?id=5dda7be9cac61c5885776c4a03411770" defer ></script>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="font-sans text-gray-900 antialiased">
    <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">


        <div
            class="w-full <?php echo e(request()->routeIs('register') ? 'sm:max-w-xl' : 'sm:max-w-md'); ?> mt-6 px-6 py-8 bg-white shadow-xl overflow-hidden sm:rounded-lg">
            <div class="flex justify-center items-center space-x-4">
                <img src="<?php echo e(asset('images/school_logo.jpg')); ?>" class="h-20" alt="">
                <img src="<?php echo e(asset('images/ccs_logo.jpg')); ?>" class="h-20" alt="">
            </div>
            <div class="text-center mt-3 text-2xl text-gray-500 uppercase font-bold">CCS Internship Portal</div>
            <div class="mt-10">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/layouts/guest.blade.php ENDPATH**/ ?>