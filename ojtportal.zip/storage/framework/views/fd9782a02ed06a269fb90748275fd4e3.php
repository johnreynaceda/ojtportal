<div>
    <div class="grid grid-cols-6 gap-5">
        <div class="col-span-4">
            <div class="grid grid-cols-2 gap-5">
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.trainee','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.trainee'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f)): ?>
<?php $attributes = $__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f; ?>
<?php unset($__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f)): ?>
<?php $component = $__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f; ?>
<?php unset($__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Trainee</h1>
                        <h1 class="text-4xl font-bold"><?php echo e($trainee); ?></h1>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginal734b7442168fb791e93313ea6728f239 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal734b7442168fb791e93313ea6728f239 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.deployed','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.deployed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal734b7442168fb791e93313ea6728f239)): ?>
<?php $attributes = $__attributesOriginal734b7442168fb791e93313ea6728f239; ?>
<?php unset($__attributesOriginal734b7442168fb791e93313ea6728f239); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal734b7442168fb791e93313ea6728f239)): ?>
<?php $component = $__componentOriginal734b7442168fb791e93313ea6728f239; ?>
<?php unset($__componentOriginal734b7442168fb791e93313ea6728f239); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Deployed</h1>
                        <h1 class="text-4xl font-bold"><?php echo e($trainee); ?></h1>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginalf773ccac9361394a49253ca4a51a8330 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf773ccac9361394a49253ca4a51a8330 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.completed','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.completed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf773ccac9361394a49253ca4a51a8330)): ?>
<?php $attributes = $__attributesOriginalf773ccac9361394a49253ca4a51a8330; ?>
<?php unset($__attributesOriginalf773ccac9361394a49253ca4a51a8330); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf773ccac9361394a49253ca4a51a8330)): ?>
<?php $component = $__componentOriginalf773ccac9361394a49253ca4a51a8330; ?>
<?php unset($__componentOriginalf773ccac9361394a49253ca4a51a8330); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Completed</h1>
                        <h1 class="text-4xl font-bold"><?php echo e($completed); ?></h1>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginal88c5dbdf01b942995d8fdcba8b7e9602 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal88c5dbdf01b942995d8fdcba8b7e9602 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.dropped','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.dropped'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal88c5dbdf01b942995d8fdcba8b7e9602)): ?>
<?php $attributes = $__attributesOriginal88c5dbdf01b942995d8fdcba8b7e9602; ?>
<?php unset($__attributesOriginal88c5dbdf01b942995d8fdcba8b7e9602); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88c5dbdf01b942995d8fdcba8b7e9602)): ?>
<?php $component = $__componentOriginal88c5dbdf01b942995d8fdcba8b7e9602; ?>
<?php unset($__componentOriginal88c5dbdf01b942995d8fdcba8b7e9602); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Dropped </h1>
                        <h1 class="text-4xl font-bold"><?php echo e($dropped); ?></h1>
                    </div>
                </div>

            </div>
        </div>
        <div class=" col-span-2 ">
            <div class=" bg-white rounded-2xl">
                <div class="border-b flex space-x-2 items-center p-2 px-4">
                    <h1 class="font-semibold text-gray-600">Announcement Board</h1>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="lucide lucide-megaphone text-main">
                        <path d="m3 11 18-5v12L3 14v-3z" />
                        <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
                    </svg>
                </div>
                <div class="p-4 h-56 overflow-y-auto">
                    <ul class="space-y-2">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="bg-gray-50  p-2">
                                <p class="text-xs text-justify text-gray-700">
                                    <?php echo e($item->message); ?></p>
                                <div class="flex mt-1 justify-end text-sm font-semibold space-x-1 items-center">
                                    <span>by:</span>
                                    <span>Coordinator</span>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>
                                <p class="text-center text-gray-600">No announcements found.</p>
                            </li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="grid mt-10 grid-cols-2 gap-5">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <div class="bg-white h-96 rounded-2xl ">
            <div class=" h-full p-5">
                <h1 class="mb-5 font-bold text-main uppercase">Task Rating</h1>
                <canvas id="lineChart" class="h-full"></canvas>
                <script>
                    const ctx = document.getElementById('lineChart').getContext('2d');
                    const lineChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'], // X-axis labels
                            datasets: [{
                                label: 'Sales Data',
                                data: [65, 59, 80, 81, 56, 55, 40], // Y-axis data
                                borderColor: 'rgba(75, 192, 192, 1)',
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                tension: 0.4 // For a smooth curve
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                },
                                tooltip: {
                                    enabled: true
                                }
                            },
                            scales: {
                                x: {
                                    beginAtZero: true
                                },
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>
            </div>

        </div>
        <div class="bg-white h-96 rounded-2xl ">
            <div class=" h-full p-5">
                <h1 class="mb-5 font-bold text-main uppercase">Task Accomplishment</h1>
                <canvas id="barChart"></canvas>
                <script>
                    const ctx1 = document.getElementById('barChart').getContext('2d');
                    const barChart = new Chart(ctx1, {
                        type: 'bar',
                        data: {
                            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'], // X-axis labels
                            datasets: [{
                                    label: 'Dataset Blue',
                                    data: [12, 19, 3, 5, 2, 3, 7], // Y-axis data for blue
                                    backgroundColor: 'rgba(54, 162, 235, 0.6)', // Blue color
                                    borderColor: 'rgba(54, 162, 235, 1)', // Blue border
                                    borderWidth: 1
                                },
                                {
                                    label: 'Dataset Red',
                                    data: [8, 10, 5, 2, 20, 30, 15], // Y-axis data for red
                                    backgroundColor: 'rgba(255, 99, 132, 0.6)', // Red color
                                    borderColor: 'rgba(255, 99, 132, 1)', // Red border
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                },
                                tooltip: {
                                    enabled: true
                                }
                            },
                            scales: {
                                x: {
                                    beginAtZero: true
                                },
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/coordinator-dashboard.blade.php ENDPATH**/ ?>