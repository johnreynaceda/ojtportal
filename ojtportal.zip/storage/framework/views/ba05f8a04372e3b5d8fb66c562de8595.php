<?php $__env->startSection('title', 'CLASS LISTS'); ?>
<?php if (isset($component)) { $__componentOriginalf2ed0d518c049503b2f918786787ce67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2ed0d518c049503b2f918786787ce67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.coordinator-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('coordinator-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white p-5 rounded-xl">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('coordinator.class-list', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1495344882-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2ed0d518c049503b2f918786787ce67)): ?>
<?php $attributes = $__attributesOriginalf2ed0d518c049503b2f918786787ce67; ?>
<?php unset($__attributesOriginalf2ed0d518c049503b2f918786787ce67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2ed0d518c049503b2f918786787ce67)): ?>
<?php $component = $__componentOriginalf2ed0d518c049503b2f918786787ce67; ?>
<?php unset($__componentOriginalf2ed0d518c049503b2f918786787ce67); ?>
<?php endif; ?>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/coordinator/class.blade.php ENDPATH**/ ?>