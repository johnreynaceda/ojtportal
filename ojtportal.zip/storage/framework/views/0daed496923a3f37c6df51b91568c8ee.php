<div>
    <div class="mb-3">
        <h1 class="text-xl font-bold uppercase"> <?php echo e($criteria); ?></h1>
        <h1 class="text-gray-500 text-sm">List of all questions in this criteria.</h1>
    </div>
    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/coordinator/criteria-question-list.blade.php ENDPATH**/ ?>