<div class="pl-3">
    <!--[if BLOCK]><![endif]--><?php switch($getRecord()->status):
        case (''): ?>
            <span class="text-gray-500 italic">Pending...</span>
        <?php break; ?>

        <?php case ('deployed'): ?>
            <span class="text-green-600 italic">Deployed...</span>
        <?php break; ?>

        <?php default: ?>
    <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/filament/tables/status.blade.php ENDPATH**/ ?>