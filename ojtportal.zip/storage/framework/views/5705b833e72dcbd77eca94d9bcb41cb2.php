<div x-data>
    <!--[if BLOCK]><![endif]--><?php if(auth()->user()->resume == null): ?>
        <div>
            <?php echo e($this->form); ?>

        </div>
        <div class="mt-5 flex space-x-3 items-center">
            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Submit Record','negative' => true,'squared' => true,'wire:click' => 'submitRecord','spinner' => 'submitRecord']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Close','href' => ''.e(route('student.dashboard')).'','slate' => true,'squared' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
        </div>
    <?php else: ?>
        <div class="flex justify-end">
            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'PRINT','right-icon' => 'printer','class' => 'font-semibold','slate' => true,'@click' => 'printOut($refs.printContainer.outerHTML);']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
        </div>
        <div class="mt-5" x-ref="printContainer">
            <div class="h-64 flex relative space-x-20 items-center justify-center w-full bg-main">
                <div class="  border h-56 w-56 absolute left-10 top-[3rem] bg-gray-400 ">
                    <img src="<?php echo e(Storage::url(auth()->user()->resume->photo)); ?>" class="h-full w-full object-cover" alt="">
                </div>
                <div class="w-40">

                </div>
                <div>
                    <p class="text-2xl uppercase text-yellow-400 font-bold">
                        <?php echo e(auth()->user()->name); ?>

                    </p>
                    <h1 class=" text-xl uppercase mt-3 text-yellow-400 ">
                        <?php echo e(auth()->user()->student->major); ?> Student
                    </h1>
                </div>
            </div>
            <div class="mt-20 grid grid-cols-2 px-10 gap-5">
                <div class=" flex flex-col space-y-10">
                    <div>
                        <h1 class="text-3xl font-bold text-yellow-600">My Contact</h1>
                        <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                        <ul class="mt-5 space-y-2">
                            <?php
                                $contact = json_decode(auth()->user()->resume->contact, true);

                            ?>
                            <li class="flex space-x-2 item-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-mail">
                                    <rect width="20" height="16" x="2" y="4" rx="2" />
                                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                                </svg>
                                <span><?php echo e($contact['email']); ?></span>
                            </li>
                            <li class="flex space-x-2 item-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-phone">
                                    <path
                                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                                </svg>
                                <span><?php echo e($contact['phone']); ?></span>
                            </li>
                            <li class="flex space-x-2 item-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-map-pin-house">
                                    <path
                                        d="M15 22a1 1 0 0 1-1-1v-4a1 1 0 0 1 .445-.832l3-2a1 1 0 0 1 1.11 0l3 2A1 1 0 0 1 22 17v4a1 1 0 0 1-1 1z" />
                                    <path d="M18 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 .601.2" />
                                    <path d="M18 22v-3" />
                                    <circle cx="10" cy="10" r="3" />
                                </svg>
                                <span><?php echo e($contact['address']); ?></span>
                            </li>
                            <li class="flex space-x-2 item-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="lucide lucide-globe">
                                    <circle cx="12" cy="12" r="10" />
                                    <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
                                    <path d="M2 12h20" />
                                </svg>
                                <span><?php echo e($contact['social']); ?></span>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-yellow-600">Hard Skill</h1>
                        <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                        <ul class="mt-5 space-y-2">
                            <?php
                                $skill = json_decode(auth()->user()->resume->hard_skill, true);
                            ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex space-x-2 item-center">
                                    <?php echo e($item['skill']); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-yellow-600">Soft Skill</h1>
                        <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                        <ul class="mt-5 space-y-2">
                            <?php
                                $skill = json_decode(auth()->user()->resume->soft_skill, true);
                            ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex space-x-2 item-center">
                                    <?php echo e($item['skill']); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-yellow-600">Education Background</h1>
                        <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                        <ul class="mt-5 space-y-2">
                            <?php
                                $skill = json_decode(auth()->user()->resume->education_background, true);
                            ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="">
                                    <p class="font-semibold"><?php echo e($item['school_name']); ?></p>
                                    <p><?php echo e($item['degree']); ?></p>
                                    <p><?php echo e($item['year']); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                </div>
                <div>
                    <div class="flex flex-col space-y-10">
                        <div>
                            <h1 class="text-3xl font-bold text-yellow-600">Career Objectives</h1>
                            <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                            <ul class="mt-5 space-y-2">
                                <?php
                                    $skill = auth()->user()->resume->career_objective;
                                ?>
                                <p><?php echo e($skill); ?></p>
                            </ul>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold text-yellow-600">WORK EXPERIENCE</h1>
                            <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                            <ul class="mt-5 space-y-2">
                                <?php
                                    $skill = json_decode(auth()->user()->resume->work_experience, true);
                                ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li class="">
                                        <p class="font-semibold"><?php echo e($item['name']); ?></p>
                                        <p><?php echo e($item['type_of_work']); ?></p>
                                        <p>
                                            <?php echo e(\Carbon\Carbon::parse($item['date_from'])->format('F Y')); ?> -
                                            <!--[if BLOCK]><![endif]--><?php if($item['present'] ?? false): ?> <!-- Use null coalescing operator -->
                                                Present
                                            <?php else: ?>
                                                <?php echo e(\Carbon\Carbon::parse($item['date_to'])->format('F Y')); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </p>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold text-yellow-600">Awards</h1>
                            <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                            <ul class="mt-5 space-y-2">
                                <?php
                                    $skill = json_decode(auth()->user()->resume->award, true);
                                ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex space-x-2 item-center">
                                        <?php echo e($item['award']); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold text-yellow-600">Certifications</h1>
                            <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                            <ul class="mt-5 space-y-2">
                                <?php
                                    $skill = json_decode(auth()->user()->resume->certification, true);
                                ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex space-x-2 item-center">
                                        <?php echo e($item['certificate']); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-10 px-10">
                <div>
                    <h1 class="text-3xl font-bold text-yellow-600">Character References</h1>
                    <div class="mt-2 h-1 w-40 bg-yellow-800"></div>
                    <ul class="mt-5 grid grid-cols-4 gap-5">
                        <?php
                            $skill = json_decode(auth()->user()->resume->character_reference, true);
                        ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="">
                                <p class="font-semibold"><?php echo e($item['name']); ?></p>
                                <p><?php echo e($item['relation']); ?></p>
                                <p><?php echo e($item['number']); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/student/resume.blade.php ENDPATH**/ ?>