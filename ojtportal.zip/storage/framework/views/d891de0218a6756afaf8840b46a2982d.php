<div>
    <div class="grid grid-cols-6 gap-5">
        <div class="col-span-4">
            <div class="grid grid-cols-2 gap-5">
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.trainee','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.trainee'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f)): ?>
<?php $attributes = $__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f; ?>
<?php unset($__attributesOriginale38e0f3aa3fc733554ce4ac4dafbe57f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f)): ?>
<?php $component = $__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f; ?>
<?php unset($__componentOriginale38e0f3aa3fc733554ce4ac4dafbe57f); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Trainee</h1>
                        <h1 class="text-4xl font-bold"><?php echo e($trainees->count()); ?></h1>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginal3356ea1ccd042bb99d7bbc801db0bb95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3356ea1ccd042bb99d7bbc801db0bb95 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.pending','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.pending'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3356ea1ccd042bb99d7bbc801db0bb95)): ?>
<?php $attributes = $__attributesOriginal3356ea1ccd042bb99d7bbc801db0bb95; ?>
<?php unset($__attributesOriginal3356ea1ccd042bb99d7bbc801db0bb95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3356ea1ccd042bb99d7bbc801db0bb95)): ?>
<?php $component = $__componentOriginal3356ea1ccd042bb99d7bbc801db0bb95; ?>
<?php unset($__componentOriginal3356ea1ccd042bb99d7bbc801db0bb95); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Completed</h1>
                        <h1 class="text-4xl font-bold"><?php echo e($completed); ?></h1>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginalb76495b15fc8b14217f5915f75a849a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb76495b15fc8b14217f5915f75a849a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.absent','data' => ['class' => 'h-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.absent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb76495b15fc8b14217f5915f75a849a6)): ?>
<?php $attributes = $__attributesOriginalb76495b15fc8b14217f5915f75a849a6; ?>
<?php unset($__attributesOriginalb76495b15fc8b14217f5915f75a849a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb76495b15fc8b14217f5915f75a849a6)): ?>
<?php $component = $__componentOriginalb76495b15fc8b14217f5915f75a849a6; ?>
<?php unset($__componentOriginalb76495b15fc8b14217f5915f75a849a6); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Absentees</h1>
                        <h1 class="text-4xl font-bold"><?php echo e($absents); ?></h1>
                    </div>
                </div>
                <div class="bg-white rounded-2xl p-5 grid grid-cols-3">
                    <div class="grid place-content-center">
                        <?php if (isset($component)) { $__componentOriginal0a7324cc7d79980aa745839345402d22 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a7324cc7d79980aa745839345402d22 = $attributes; } ?>
<?php $component = App\View\Components\Shared\Clock::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.clock'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Shared\Clock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a7324cc7d79980aa745839345402d22)): ?>
<?php $attributes = $__attributesOriginal0a7324cc7d79980aa745839345402d22; ?>
<?php unset($__attributesOriginal0a7324cc7d79980aa745839345402d22); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a7324cc7d79980aa745839345402d22)): ?>
<?php $component = $__componentOriginal0a7324cc7d79980aa745839345402d22; ?>
<?php unset($__componentOriginal0a7324cc7d79980aa745839345402d22); ?>
<?php endif; ?>
                    </div>
                    <div class="col-span-2 text-gray-600">
                        <h1 class="text-xl">Pending Tasks </h1>
                        <h1 class="text-4xl font-bold"><?php echo e($tasks); ?></h1>
                    </div>
                </div>

            </div>

        </div>
        <div class=" col-span-2 ">
            <div class=" bg-white rounded-2xl">
                <div class="border-b flex space-x-2 items-center p-2 px-4">
                    <h1 class="font-semibold text-gray-600">Announcement Board</h1>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="lucide lucide-megaphone text-main">
                        <path d="m3 11 18-5v12L3 14v-3z" />
                        <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
                    </svg>
                </div>
                <div class="p-4 h-56 overflow-y-auto">
                    <ul class="space-y-2">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="bg-gray-50  p-2">
                                <p class="text-xs text-justify text-gray-700">
                                    <?php echo e($item->message); ?></p>
                                <div class="flex mt-1 justify-end text-sm font-semibold space-x-1 items-center">
                                    <span>by:</span>
                                    <span>Coordinator</span>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </ul>
                </div>
            </div>
        </div>

    </div>
    <div class="grid mt-10 grid-cols-2 gap-5">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <div class="bg-white h-96 rounded-2xl ">
            <div class=" h-full p-5">
                <h1 class="mb-5 font-bold text-main uppercase">Task Rating</h1>
                <canvas id="lineChart" class="h-full"></canvas>
                <script>
                    const ctx = document.getElementById('lineChart').getContext('2d');
                    const lineChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'], // X-axis labels
                            datasets: [{
                                label: 'Sales Data',
                                data: [65, 59, 80, 81, 56, 55, 40], // Y-axis data
                                borderColor: 'rgba(75, 192, 192, 1)',
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                tension: 0.4 // For a smooth curve
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                },
                                tooltip: {
                                    enabled: true
                                }
                            },
                            scales: {
                                x: {
                                    beginAtZero: true
                                },
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>
            </div>

        </div>
        <div class="bg-white h-96 rounded-2xl ">
            <div class=" h-full p-5">
                <h1 class="mb-5 font-bold text-main uppercase">Task Accomplishment</h1>
                <canvas id="barChart"></canvas>
                <script>
                    const ctx1 = document.getElementById('barChart').getContext('2d');
                    const barChart = new Chart(ctx1, {
                        type: 'bar',
                        data: {
                            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'], // X-axis labels
                            datasets: [{
                                    label: 'Dataset Blue',
                                    data: [12, 19, 3, 5, 2, 3, 7], // Y-axis data for blue
                                    backgroundColor: 'rgba(54, 162, 235, 0.6)', // Blue color
                                    borderColor: 'rgba(54, 162, 235, 1)', // Blue border
                                    borderWidth: 1
                                },
                                {
                                    label: 'Dataset Red',
                                    data: [8, 10, 5, 2, 20, 30, 15], // Y-axis data for red
                                    backgroundColor: 'rgba(255, 99, 132, 0.6)', // Red color
                                    borderColor: 'rgba(255, 99, 132, 1)', // Red border
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                },
                                tooltip: {
                                    enabled: true
                                }
                            },
                            scales: {
                                x: {
                                    beginAtZero: true
                                },
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/supervisor-dashboard.blade.php ENDPATH**/ ?>