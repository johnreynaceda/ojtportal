<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/student/my-absent.blade.php ENDPATH**/ ?>