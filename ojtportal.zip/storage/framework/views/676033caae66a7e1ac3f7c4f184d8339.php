<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/supervisor/student-rate.blade.php ENDPATH**/ ?>