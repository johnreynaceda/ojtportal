<div class="pl-3">
    <p class="text-sm">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getRecord()->taskAssignedStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($item->trainee->student->user->name); ?><!--[if BLOCK]><![endif]--><?php if(!$loop->last): ?>
                ,
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </p>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/filament/tables/assigned.blade.php ENDPATH**/ ?>