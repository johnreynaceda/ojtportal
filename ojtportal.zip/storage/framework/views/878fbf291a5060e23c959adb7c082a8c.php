<?php $__env->startSection('title', 'My Requirements'); ?>
<?php if (isset($component)) { $__componentOriginale6bb6d51ea1728354169f27061d92679 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6bb6d51ea1728354169f27061d92679 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white p-5 rounded-xl">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('student.upload-requirement', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3766316552-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6bb6d51ea1728354169f27061d92679)): ?>
<?php $attributes = $__attributesOriginale6bb6d51ea1728354169f27061d92679; ?>
<?php unset($__attributesOriginale6bb6d51ea1728354169f27061d92679); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6bb6d51ea1728354169f27061d92679)): ?>
<?php $component = $__componentOriginale6bb6d51ea1728354169f27061d92679; ?>
<?php unset($__componentOriginale6bb6d51ea1728354169f27061d92679); ?>
<?php endif; ?>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/student/requirement/edited-docs.blade.php ENDPATH**/ ?>