<?php $__env->startSection('title', 'My Resume'); ?>
<?php if (isset($component)) { $__componentOriginale6bb6d51ea1728354169f27061d92679 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6bb6d51ea1728354169f27061d92679 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white p-5 rounded-xl">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('student.resume', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1317395281-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <script>
            function printOut(data) {
                var mywindow = window.open('', '', 'height=1000,width=1000');
                mywindow.document.head.innerHTML =
                    '<title></title><link rel="stylesheet" href="<?php echo e(Vite::asset('resources/css/app.css')); ?>" />';
                mywindow.document.body.innerHTML = '<div>' + data +
                    '</div><script src="<?php echo e(Vite::asset('resources/js/app.js')); ?>"/>';

                mywindow.document.close();
                mywindow.focus(); // necessary for IE >= 10
                setTimeout(() => {
                    mywindow.print();
                    return true;
                }, 1000);
            }
        </script>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6bb6d51ea1728354169f27061d92679)): ?>
<?php $attributes = $__attributesOriginale6bb6d51ea1728354169f27061d92679; ?>
<?php unset($__attributesOriginale6bb6d51ea1728354169f27061d92679); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6bb6d51ea1728354169f27061d92679)): ?>
<?php $component = $__componentOriginale6bb6d51ea1728354169f27061d92679; ?>
<?php unset($__componentOriginale6bb6d51ea1728354169f27061d92679); ?>
<?php endif; ?>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/student/resume.blade.php ENDPATH**/ ?>