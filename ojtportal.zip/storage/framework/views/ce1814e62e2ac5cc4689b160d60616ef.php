<?php $__env->startSection('title', 'DTR RECORDS'); ?>
<?php if (isset($component)) { $__componentOriginal59d39b7879af7cc55a8c0abc827bcaea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59d39b7879af7cc55a8c0abc827bcaea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.supervisor-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('supervisor-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white p-5 rounded-xl">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('supervisor.view-dtr', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3469142538-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59d39b7879af7cc55a8c0abc827bcaea)): ?>
<?php $attributes = $__attributesOriginal59d39b7879af7cc55a8c0abc827bcaea; ?>
<?php unset($__attributesOriginal59d39b7879af7cc55a8c0abc827bcaea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59d39b7879af7cc55a8c0abc827bcaea)): ?>
<?php $component = $__componentOriginal59d39b7879af7cc55a8c0abc827bcaea; ?>
<?php unset($__componentOriginal59d39b7879af7cc55a8c0abc827bcaea); ?>
<?php endif; ?>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/coordinator/view-attendance.blade.php ENDPATH**/ ?>