<div>
    <div class="flex flex-col">
        <div class=" overflow-x-auto">
            <div class="min-w-full inline-block align-middle">
                <div class="overflow-hidden border rounded-lg border-gray-300">
                    <table class=" min-w-full  rounded-xl">
                        <thead>
                            <tr class="bg-gray-50">
                                <th scope="col" class="p-2  text-center leading-6 font-bold text-gray-900 capitalize">
                                    CRITERIA FOR EVALUATION</th>
                                <th scope="col"
                                    class=" w-40 p-2 text-left text-sm leading-6 font-semibold text-gray-900 capitalize">
                                    MAXIMUM POINTS </th>
                                <th scope="col"
                                    class=" w-40 p-2 text-left text-sm leading-6 font-semibold text-gray-900 capitalize">
                                    POINTS EARNED
                                </th>

                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-300 ">
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="bg-gray-50 border-t">
                                    <td scope="col"
                                        class="p-2 text-left text-main uppercase leading-6 font-semibold ">
                                        <?php echo e($criteria->name); ?> </td>
                                    <td scope="col"
                                        class="w-40p-2  text-sm text-center text-main leading-6 font-semibold  capitalize">
                                        (<?php echo e($criteria->criteriaQuestions->sum('max_point')); ?>)
                                    </td>
                                    <td scope="col"
                                        class="w-40 p-2 text-left text-sm leading-6 font-semibold text-gray-900 capitalize">
                                    </td>

                                </tr>
                                <?php
                                    $i = 1;
                                ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $criteria->criteriaQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="p-2 text-sm leading-6 font-medium text-gray-900">
                                            <p class="pl-10">
                                                <strong class="pr-2"><?php echo e($loop->iteration); ?>.</strong>
                                                <?php echo e($item->question); ?>

                                            </p>
                                        </td>

                                        <td
                                            class="w-40 p-2 whitespace-nowrap text-sm leading-6 font-medium text-center text-gray-900">
                                            <?php echo e($item->max_point); ?>

                                        </td>

                                        <td
                                            class="w-40 p-2 whitespace-nowrap text-sm leading-6 font-medium text-center text-gray-900">
                                            <input type="number"
                                                wire:model.debounce.500ms="points.<?php echo e($item->id); ?>.earned"
                                                class="w-10 border rounded text-center p-1" min="0"
                                                max="<?php echo e($item->max_point); ?>" />

                                            <input type="hidden" wire:model="points.<?php echo e($item->id); ?>.id"
                                                value="<?php echo e($item->id); ?>">

                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["points.<?php echo e($item->id); ?>.earned"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\ojtportal\resources\views/livewire/supervisor/performance-rating.blade.php ENDPATH**/ ?>